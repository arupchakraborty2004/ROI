import React, { Component } from "react";
import "./styles.css";
import Chart from "./components/chart.jsx";
import Product from "./components/product.jsx";
import ProductDetails from "./components/productdetails.jsx";
import { connect } from "react-redux";
import * as actions from "./actions/events";
import { bindActionCreators } from "redux";

class App extends Component {
  constructor(props) {
    super(props);
    this.setState({
      data: []
    });
    this.props.actions.getSalesInfo();
  }

  render() {
    let salesData = this.props.salesInfoReducer.data;

    return (
      <div className="App">
        <h2> Stackline Chart</h2>
        <div className="container">
          <div className="leftCls">
            <Product data={salesData} />
          </div>
          <div className="rightCls">
            <div className="salesChart">
              <Chart data={salesData} />
            </div>

            <div className="salesTbl">
              <ProductDetails data={salesData} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(actions, dispatch)
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
