import { GET_SALES_DATA, GET_SALES_DATA_SUCCESS } from "../constants";
import data from '../source/Webdev_data2.json';

const initialState = { data: data };

export default function salesInfoReducer(state = initialState, action) {
  switch (action.type) {
    case GET_SALES_DATA:
      
      return {
        ...state
      };

    case GET_SALES_DATA_SUCCESS:
      
      state.data = action.payload;
      return {
        ...state,
        data: action.payload
      };

    default:
      return state;
  }
}
