import { combineReducers } from "redux";
import salesInfoReducer from "./salesInfoReducers";

export default combineReducers({
  salesInfoReducer
});
