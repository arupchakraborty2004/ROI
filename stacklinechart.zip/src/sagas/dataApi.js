import data from "../source/Webdev_data2.json";

export async function getSalesData() {
  const response = await fetch(data);
  return response.json();
}
