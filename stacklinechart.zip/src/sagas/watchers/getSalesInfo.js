import { put, call, takeEvery } from "redux-saga/effects";
import { GET_SALES_DATA, GET_SALES_DATA_SUCCESS } from "../../constants";
import { getSalesData } from "../dataApi.js";

function* workerGetSalesDataSaga() {
  console.log("saga called");
  var salesData = yield call(getSalesData);
  console.log("sales " + salesData);
  yield put({ type: GET_SALES_DATA_SUCCESS, payload: salesData });
}

export default function* watchGetSalesInfoSaga() {
  console.log("saga called");
  yield takeEvery(GET_SALES_DATA, workerGetSalesDataSaga);
}
