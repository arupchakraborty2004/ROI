import { all, fork } from "redux-saga/effects";
import watchGetSalesInfoSaga from "./watchers/getSalesInfo";

export default function* root() {
  yield all[fork(watchGetSalesInfoSaga)];
}
