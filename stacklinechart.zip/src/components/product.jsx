import React, { Component } from "react";
import "../styles.css";

class Product extends Component {
  render() {
    let data = this.props.data;
    var tags = data[0].tags;
    console.log(tags);
    return (
      <div>
        <img
          src={data[0].image}
          alt={data[0].title}
          height="150px"
          width="150px"
        />
        <h4>{data[0].title}</h4>
        <div className="subtitle">{data[0].subtitle}</div>
        <div className="div-tags">
          {tags.map(({ tag }, i) => (
            <span className="tag" key={i}>
              {tags[i]}
            </span>
          ))}
        </div>
      </div>
    );
  }
}

export default Product;
