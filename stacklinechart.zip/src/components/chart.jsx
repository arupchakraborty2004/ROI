import React, { Component } from "react";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import "../styles.css";

class Chart extends Component {
  render() {
    var data = this.props.data;

    var retailSales = [];
    var wholeSales = [];

    for (var i = 0; i < 12; i++) {
      retailSales.push(this.groupByMonth(data[0].sales)[0][i]);
      wholeSales.push(this.groupByMonth(data[0].sales)[1][i]);
    }

    const options = {
      chart: {
        type: "spline"
      },
      title: {
        text: "Retail Sales"
      },
      yAxis: {
        startOnTick: false,
        endOnTick: false,
        tickPositions: [],
        labels: { enabled: false },
        title: {
          text: null
        }
      },
      xAxis: {
        categories: [
          "JAN",
          "FEB",
          "MAR",
          "APR",
          "MAY",
          "JUN",
          "JUL",
          "AUG",
          "SEP",
          "OCT",
          "NOV",
          "DEC"
        ]
      },
      series: [
        {
          name: "Retail Sales",
          data: retailSales
        },
        {
          name: "WholeSales Sales",
          data: wholeSales
        }
      ]
    };

    return (
      <div className="">
        <HighchartsReact highcharts={Highcharts} options={options} />
      </div>
    );
  }

  groupByMonth(array) {
    var aggregate = [];
    var groupByMonthSales = {};
    var groupByMonthWholeSales = {};

    for (var i = 0; i < array.length; i++) {
      var retailsSale = 0;
      var wholeSales = 0;
      var date = new Date(array[i].weekEnding);
      date = date.getMonth();
      retailsSale = array[i].retailSales;
      wholeSales = array[i].wholesaleSales;

      if (groupByMonthSales[date] === undefined) groupByMonthSales[date] = [];
      if (groupByMonthWholeSales[date] === undefined)
        groupByMonthWholeSales[date] = [];

      retailsSale = Number(groupByMonthSales[date]) + Number(retailsSale);
      wholeSales = Number(groupByMonthWholeSales[date]) + Number(wholeSales);

      groupByMonthSales[date] = retailsSale;
      groupByMonthWholeSales[date] = wholeSales;
    }

    aggregate.push(groupByMonthSales);
    aggregate.push(groupByMonthWholeSales);
    return aggregate;
  }
}

export default Chart;
