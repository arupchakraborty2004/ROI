import React, { Component } from "react";
import "../styles.css";

class ProductDetails extends Component {
  render() {
    let data = this.props.data;
    let productDetails = data[0].sales;

    return (
      <div className="rTable">
        <div className="rTableRow">
          <div className="rTableHead">WEEK ENDING</div>
          <div className="rTableHead">RETAIL SALES</div>
          <div className="rTableHead">WHOLESALE SALES</div>
          <div className="rTableHead">UNITS SOLD</div>
          <div className="rTableHead">RETAILER MARGIN</div>
        </div>
        <div className="rowContainer">
          {productDetails.map(({ tag }, i) => (
            <div className="rTableRow">
              <div className="rTableCell" key={i}>
                {productDetails[i].weekEnding}
              </div>
              <div className="rTableCell" key={i}>
                {productDetails[i].retailSales.toLocaleString("en-US", {
                  style: "currency",
                  currency: "USD"
                })}
              </div>
              <div className="rTableCell" key={i}>
                {productDetails[i].wholesaleSales.toLocaleString("en-US", {
                  style: "currency",
                  currency: "USD"
                })}
              </div>
              <div className="rTableCell" key={i}>
                {productDetails[i].unitsSold}
              </div>
              <div className="rTableCell" key={i}>
                {productDetails[i].retailerMargin.toLocaleString("en-US", {
                  style: "currency",
                  currency: "USD"
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

export default ProductDetails;
