import * as events from "./events.js";

export default { ...events };
