import { GET_SALES_DATA } from "../constants";

export function getSalesInfo() {
  return {
    type: GET_SALES_DATA
  };
}
