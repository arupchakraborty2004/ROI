import React, { Component } from 'react';
import './ChatDetails.css';
import Messages from "./Messages";
import Input from "./Input";
import * as actions from '../../actions/events';
import {bindActionCreators} from "redux";
import {connect} from "react-redux";


function randomColor() {
    return '#' + Math.floor(Math.random() * 0xFFFFFF).toString(16);
}

class Index extends Component {


    constructor(props) {
        super(props);

        this.state = {
            messages: [],
            member: {
                username: this.props.match.params.username,
                color: randomColor(),
            },
            members: [],
            roomId : this.props.match.params.roomId
        };

       this.props.actions.getUserMessages(this.state.roomId); // get the messages
       this.props.actions.getChatRoomDetails(this.state.roomId); // get chat room users
    }

    render() {


        var members = [];

        var roomDetails = this.props.props.chatReducer.roomDetails;
        var userList = roomDetails.users !== undefined ? roomDetails.users : [];
        for (let i = 0; i < userList.length; i++) {

            const userName = userList[i];

            members.push({

                username : userName
            });

        }

        return (
            <div className="App">
                <div className="App-header">
                    <div className="App-heading">Welcome to Chat</div>

                    {members.length>0 &&
                      <div className="div-display">
                        {members.map(({
                                          username
                                      }, i) => (
                            <span className="head-padding" key={i}>
                                {
                                    <span>{username} </span>

                                }
                            </span>))}
                      </div>}
                    <div>Current user : {this.state.member.username}</div>
                </div>
                <Messages
                    messages={this.props.props.chatReducer.messages}
                    currentMember={this.state.member}
                />
                <Input
                    onSendMessage={this.onSendMessage}
                />
            </div>
        );
    }

    onSendMessage = (message) => {

       var msg = {
           roomId:0,
           message: message,
           name: this.state.member.username
       }

       this.props.actions.setUserMessages(msg);
    }

};

const mapStateToProps =(state) => {
    return {
        props: {...state}
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        actions: bindActionCreators(actions, dispatch)
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Index);
