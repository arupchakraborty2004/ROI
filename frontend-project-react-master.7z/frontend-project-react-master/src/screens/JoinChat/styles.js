const styles = {
  container: {
    marginLeft: 40,
    marginRight: 40,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40
  },

  innerContainer : {
    maxHeight: 170
  },

  joinBtnStyle:{
    marginTop: 25,
    color: '#FFFFFF',
    backgroundColor: '#FF4500'
  },

  inputStyle:{
    width: '320px'
  },

  selectStyle:{
    marginTop: 20,
    padding: 5
  },

  selectOptionHeaderStyle:{
      marginTop: 10,
      color: '#FF4500'
  }
};

export default styles;
