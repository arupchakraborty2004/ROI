import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Button, Table } from 'semantic-ui-react';

import { getUsersSaga } from '../../actions';
import { history } from '../../store';
import { Route, Redirect, Switch } from 'react-router-dom';
import * as actions from '../../actions/events';

import styles from './styles';
import {bindActionCreators} from "redux";

class JoinChat extends Component {

    constructor(props) {
        super(props);

        this.handleBtnOnClick = this.handleBtnOnClick.bind(this);
        this.setState({
            username : '',
            roomId: 0,
            rooms: [],
            chatRoomName: ''
        });
        this.setUserName = this.onSetUserName.bind(this);

        this.props.actions.getChatRooms();
    }

    handleBtnOnClick() {

        this.props.history.push('/Index/'+ this.state.roomId + "/" + this.state.username);
    }

    onSetUserName(name)
    {
        this.setState({
            username: name,
            roomId: 0
        });
    }

    onChatRoomChange(selected)
    {
        alert(selected)
    }

    render() {

        var chatRooms = this.props.chatReducer.rooms;

        return (
            <div style={styles.container}>

                <div style={styles.innerContainer}>
                    <input style={styles.inputStyle} onChange={(evt) => { this.setUserName(evt.target.value); }} type="text" placeholder="Type your username..." />
                    <Button
                        onClick={this.handleBtnOnClick}
                        style={styles.joinBtnStyle}
                    >
                        Join DoorDash Chat
                    </Button>
                    <div style={styles.selectOptionHeaderStyle}> Select a chat room</div>
                    {chatRooms !== undefined &&
                    <select style={styles.selectStyle} value={this.props.roomId}
                            onChange={(e) => this.setState({roomId: e.target.value })}>
                        {chatRooms.map((room) => <option key={room.id} value={room.id}>{room.name}</option>)}
                    </select>
                    }

                </div>
            </div>
        );
    }
}

const mapStateToProps = state => ({
    ...state
});

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(actions, dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(JoinChat);
