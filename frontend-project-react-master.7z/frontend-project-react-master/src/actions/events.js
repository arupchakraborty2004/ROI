import { GET_USERS_SAGA, SET_USERS, GET_CHAT_ROOMS, GET_CHATROOM_DETAILS, GET_USERS_MESSAGES, POST_MESSAGES, SET_CHAT_USERS } from '../constants';

export function setUsers(users) {
  return {
    type: SET_USERS,
    users
  };
};

//Sagas
export function getUsersSaga() {
  return {
    type: GET_USERS_SAGA
  };
};

export function setUserName(name){
  return {
    type: 'USER_NAME',
    payload: name
  }
};

export function setUserMessages(message){

  return{
    type:'POST_MESSAGES',
    payload: message
  }
};

export function getUserMessages(roomId){
  return{
    type:'GET_USERS_MESSAGES',
    payload: roomId
  }
};

export function getChatRooms(){
  return{
  type:'GET_CHAT_ROOMS'
}};

export function getChatRoomDetails(roomId){
  return{
    type:'GET_CHATROOM_DETAILS',
    payload: roomId
  }
};
