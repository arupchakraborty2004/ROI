import React, { Component } from 'react';
import { Provider } from 'react-redux';
import { ConnectedRouter } from 'connected-react-router';
import { Route, Redirect, Switch } from 'react-router-dom';

import store, { history } from './store';

import Index from './screens/ChatDetails';
import JoinChat from './screens/JoinChat'

import 'semantic-ui-css/semantic.min.css';
import './App.css';

export default class App extends Component {

    constructor()
    {
        super();
    }

  render() {
    return (
      <Provider store={store}>
        <ConnectedRouter history={history}>
          <div>
              <Switch>
                  <Route exact={true} path="/" component={JoinChat} />
                  <Route exact={true} path="/Index/:roomId/:username" component={Index} />
              </Switch>
          </div>
        </ConnectedRouter>
      </Provider>
    );
  }
}
