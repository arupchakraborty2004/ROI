import { all, fork } from 'redux-saga/effects';

import watchGetUsersSaga from './watchers/getUsers';
import watchGetMessagesSaga from './watchers/getChatMessages';
import watchChatRoomDetails from './watchers/getChatRoomDetails';
import watchChatRooms from './watchers/getChatRooms';
import watchPostMessagesSaga from './watchers/postChatMessages';

export default function* root() {
  yield [
      fork(watchGetUsersSaga),
      fork(watchGetMessagesSaga),
      fork(watchChatRoomDetails),
      fork(watchChatRooms),
      fork(watchPostMessagesSaga)
  ];
}
