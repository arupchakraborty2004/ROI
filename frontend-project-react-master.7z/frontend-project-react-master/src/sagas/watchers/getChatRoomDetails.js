import { put, takeEvery, call, select } from 'redux-saga/effects';

import { GET_CHATROOM_DETAILS, GET_CHATROOM_DETAILS_SUCCESS } from '../../constants';
import { getUserMessages } from '../../actions';
import { getRoomDetails } from '../../lib/api';

function* workerGetChatRoomDetailsSaga() {

    const inputs = yield select(state => state.inputs);
    let roomId=0;
    if(inputs === undefined)
    {
        roomId = 0;
    }

    const roomDetails = yield call(getRoomDetails, roomId);
    yield put({type: GET_CHATROOM_DETAILS_SUCCESS, payload: roomDetails});
}

export default function* watchGetChatRoomDetailsSaga() {
    yield takeEvery(GET_CHATROOM_DETAILS, workerGetChatRoomDetailsSaga);
}
