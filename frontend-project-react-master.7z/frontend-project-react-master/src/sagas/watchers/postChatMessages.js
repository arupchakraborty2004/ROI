import { put, takeEvery, call, select } from 'redux-saga/effects';

import {  POST_MESSAGES , POST_MESSAGES_SUCCESS } from '../../constants';
import { setUserMessages } from '../../actions';
import { postMessages } from '../../lib/api';

// TODO : the post message call is failing , so adding an in-memory collection to test the code
function* workerPostMessageSaga() {

    var message = yield select(state => state);
    try {
        const postMessage = yield call(postMessages, message.chatReducer.message.roomId, message.chatReducer.message);
        yield put({type: POST_MESSAGES_SUCCESS, payload: postMessage});
    }
    catch (e) {
        console.log(e);
        message.chatReducer.messages.push(message.chatReducer.message);
        yield put({type: POST_MESSAGES_SUCCESS, payload: message.chatReducer.messages});
    }
}

export default function* watchPostMessagesSaga() {
    yield takeEvery(POST_MESSAGES, workerPostMessageSaga);
}
