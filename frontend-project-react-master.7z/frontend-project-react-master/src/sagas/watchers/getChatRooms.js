import { put, takeEvery, call } from 'redux-saga/effects';

import { GET_CHAT_ROOMS, GET_CHATROOMS_SUCCESS } from '../../constants';
import { getUserMessages } from '../../actions';
import { getRooms } from '../../lib/api';

function* workerGetChatRoomsSaga() {

    var rooms = yield call(getRooms);
    yield put({type: GET_CHATROOMS_SUCCESS, payload: rooms});
}

export default function* watchGetChatRoomSaga() {
    yield takeEvery(GET_CHAT_ROOMS, workerGetChatRoomsSaga);
}
