import { put, takeEvery, call, select } from 'redux-saga/effects';

import { GET_USERS_MESSAGES, GET_USERS_MESSAGES_SUCCESS } from '../../constants';
import { getUserMessages } from '../../actions';
import { getMessages } from '../../lib/api';

function* workerGetChatUsersSaga() {

    var inputs = yield select(state => state);

    if(inputs.chatReducer.roomId === undefined)
    {
        inputs.chatReducer.roomId = 0;
    }

    var messages = yield call(getMessages, inputs.chatReducer.roomId);
    yield put({type: GET_USERS_MESSAGES_SUCCESS, payload: messages});
}

export default function* watchGetMessagesSaga() {
    yield takeEvery(GET_USERS_MESSAGES, workerGetChatUsersSaga);
}
