import {POST_MESSAGES, GET_USERS_MESSAGES, GET_CHATROOM_DETAILS, GET_CHAT_ROOMS, GET_CHATROOM_DETAILS_SUCCESS, GET_USERS_MESSAGES_SUCCESS, POST_MESSAGES_SUCCESS, GET_CHATROOMS_SUCCESS} from '../constants';

const initialState = { roomId: '', messages:[], rooms: [], roomDetails: {} , isPostSuccess: false };

export default function chatUsers(state = initialState, action) {
    switch (action.type) {
        case POST_MESSAGES:
            state.message = action.payload;

            return {
                ...state,
                message: action.payload
            };
        case POST_MESSAGES_SUCCESS:
            return {
                ...state,
                isPostSuccess: true,
                messages: action.payload
            };
        case GET_USERS_MESSAGES:
            return {
                ...state,
                roomId: action.roomId
            };
        case GET_USERS_MESSAGES_SUCCESS:

            state.messages = action.payload;
            return {
                ...state,
                messages: action.payload
            };
        case GET_CHAT_ROOMS:
            return {
                ...state,
                roomId: action.roomId
            };
        case GET_CHATROOMS_SUCCESS:

            state.rooms = action.payload;
            return {
                ...state,
                rooms: action.payload
            };
        case GET_CHATROOM_DETAILS:
            return {
                ...state,
                roomId: action.roomId
            };
        case GET_CHATROOM_DETAILS_SUCCESS:

            state.roomDetails = action.payload;
            return {
                ...state,
                roomDetails: action.payload
            };
        default:
            return state;
    }
}
