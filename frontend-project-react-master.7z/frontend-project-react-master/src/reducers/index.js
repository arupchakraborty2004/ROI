import { combineReducers } from 'redux';

import usersReducer from './users';
import chatReducer from './chatusers';

export default combineReducers({
  usersReducer,
  chatReducer
});
